# optionz

Skeletal implementation.

## Project Status

Just a quick sketch.

## On-line Documentation

More information on the **optionz** project can be found
[here](https://jddixon.github.io/optionz)
