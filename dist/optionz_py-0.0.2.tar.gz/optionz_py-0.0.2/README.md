# optionz_py

Skeletal implementation.

## Project Status

Just a quick sketch.

## On-line Documentation

More information on the **optionz_py** project can be found
[here](https://jddixon.github.io/optionz_py)
